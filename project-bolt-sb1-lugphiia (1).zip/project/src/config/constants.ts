export const WS_CONFIG = {
  SOCKET_URL: 'http://localhost:8080/ws',
  TOPIC: '/topic/powerStatus'
} as const;