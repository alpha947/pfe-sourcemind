export interface PowerStatus {
  status: string;
  timestamp: string;
}